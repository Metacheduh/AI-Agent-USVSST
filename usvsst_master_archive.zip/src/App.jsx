import React, { useState, useEffect } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell 
} from 'recharts';
import { 
  LayoutDashboard, Database, Activity, FileText, ArrowRight, ShieldCheck, Mail, Gavel, Search, Bell
} from 'lucide-react';
import { pipelineStages, casesData, totalMetrics } from './data/mockData';
import html2pdf from 'html2pdf.js';
import './index.css';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isScraping, setIsScraping] = useState(false);
  const [generatedContent, setGeneratedContent] = useState(null);
  const [liveCases, setLiveCases] = useState(casesData); // Default to mock data initially
  const [selectedContentInfo, setSelectedContentInfo] = useState(null); // Modal state

  const handlePdfDownload = () => {
    const element = document.getElementById('pdf-content-wrapper');
    const opt = {
      margin:       1,
      filename:     `USVSST-${selectedContentInfo.title.replace(/\s+/g, '-')}.pdf`,
      image:        { type: 'jpeg', quality: 0.98 },
      html2canvas:  { scale: 2, useCORS: true },
      jsPDF:        { unit: 'in', format: 'letter', orientation: 'portrait' }
    };
    html2pdf().set(opt).from(element).save();
  };

  // Fetch the live database from our Node backend
  const fetchLiveCases = async () => {
    try {
      const resp = await fetch('http://localhost:3000/api/cases');
      const data = await resp.json();
      if (data.success && data.cases && data.cases.length > 0) {
        setLiveCases(data.cases);
      }
    } catch (e) {
      console.error("Could not fetch live DB yet.");
    }
  };

  useEffect(() => {
    fetchLiveCases();
    // Poll the DB every 10 seconds for updates
    const interval = setInterval(fetchLiveCases, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleGovWatchTrigger = async () => {
    setIsScraping(true);
    try {
      await fetch('http://localhost:3000/api/govwatch-trigger', { method: 'POST' });
      await fetchLiveCases(); // Immediately pull the new verified documents
    } catch (e) {
      alert("GovWatch failed to connect to backend on port 3000.");
    } finally {
      setIsScraping(false);
    }
  };

  const handleForceGeneration = async () => {
    setIsGenerating(true);
    setGeneratedContent(null);
    try {
      const MOCK_DOJ_ALERT = `
FOR IMMEDIATE RELEASE
Department of Justice, U.S. Attorney’s Office
Today, the United States filed a civil forfeiture complaint against $85,000,000 in Iranian sanctioned oil funds. The action, docketed as 9:25-cv-00444, ensures these assets remain seized pending litigation.`;
      
      const response = await fetch('http://localhost:3000/api/intake', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: MOCK_DOJ_ALERT })
      });
      
      const data = await response.json();
      if (data.success) {
        setGeneratedContent(data);
      } else {
        alert("Genkit Error: " + data.error);
      }
    } catch (e) {
      alert("Failed to connect to Genkit Backend API on port 3000.");
    } finally {
      setIsGenerating(false);
    }
  };
  
  return (
    <div className="flex h-screen" style={{ backgroundColor: 'var(--bg-base)' }}>
      {/* PDF Generation Modal */}
      {selectedContentInfo && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.8)', zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '2rem' }}>
          <div className="panel flex-col gap-4" style={{ width: '100%', maxWidth: '800px', maxHeight: '90vh', overflowY: 'auto', backgroundColor: 'var(--bg-base)' }}>
            <div className="flex items-center justify-between" style={{ borderBottom: '1px solid var(--border-color)', paddingBottom: '1rem' }}>
              <h2 style={{ margin: 0 }}>Review Full Content</h2>
              <div className="flex gap-2">
                <button 
                  onClick={handlePdfDownload}
                  style={{ background: 'var(--accent-blue)', color: 'white', border: 'none', padding: '0.5rem 1rem', borderRadius: '4px', cursor: 'pointer', fontWeight: 500, display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  <FileText size={16} /> Export as PDF
                </button>
                <button 
                  onClick={() => setSelectedContentInfo(null)}
                  style={{ background: 'var(--bg-surface-hover)', color: 'var(--text-primary)', border: '1px solid var(--border-color)', padding: '0.5rem 1rem', borderRadius: '4px', cursor: 'pointer', fontWeight: 500 }}>
                  Close Modal
                </button>
              </div>
            </div>
            {/* The printable section */}
            <div id="pdf-content-wrapper" style={{ padding: '2rem', backgroundColor: '#ffffff', color: '#1a1a1a', borderRadius: '4px', fontSize: '11pt', lineHeight: 1.6, fontFamily: 'Georgia, serif' }}>
              <div style={{ paddingBottom: '20px', marginBottom: '20px', borderBottom: '2px solid #222', textAlign: 'center' }}>
                <h1 style={{ margin: 0, fontSize: '16pt', textTransform: 'uppercase', letterSpacing: '2px' }}>Department of Justice - USVSST Action</h1>
                <p style={{ margin: '5px 0 0 0', color: '#555', fontSize: '10pt' }}>{selectedContentInfo.title}</p>
              </div>
              <div style={{ whiteSpace: 'pre-wrap' }}>
                {selectedContentInfo.content}
              </div>
              <div style={{ marginTop: '40px', paddingTop: '20px', borderTop: '1px solid #ccc', fontSize: '9pt', color: '#777', textAlign: 'center' }}>
                Generated by Genkit AI Prototype • Verified USVSST Data Pipeline
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Sidebar */}
      <div className="panel flex-col gap-6" style={{ width: '280px', borderRadius: 0, borderTop: 0, borderBottom: 0, borderLeft: 0, display: 'flex' }}>
        <div className="flex items-center gap-2" style={{ marginBottom: '2rem' }}>
          <ShieldCheck color="var(--accent-blue)" size={28} />
          <h2 style={{ fontSize: '1.2rem', margin: 0 }}>AI Agent USVSST</h2>
        </div>
        
        <nav className="flex-col gap-2" style={{ display: 'flex', flex: 1 }}>
          <NavItem icon={<LayoutDashboard />} label="Intelligence Dashboard" active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')} />
          <NavItem icon={<Database />} label="Cases Database" active={activeTab === 'cases'} onClick={() => setActiveTab('cases')} />
          <NavItem icon={<Activity />} label="ADK Pipelines" active={activeTab === 'adk'} onClick={() => setActiveTab('adk')} />
          <NavItem icon={<Mail />} label="Content Engine" active={activeTab === 'content'} onClick={() => setActiveTab('content')} />
        </nav>
        
        <div className="panel" style={{ padding: '1rem', backgroundColor: 'var(--bg-base)', border: '1px solid var(--border-highlight)' }}>
          <p style={{ fontSize: '0.8rem', margin: 0, color: 'var(--text-tertiary)' }}>DOJ Regulatory Analyst Mode</p>
          <div className="flex items-center justify-between" style={{ marginTop: '0.5rem' }}>
            <span style={{ fontSize: '0.9rem', fontWeight: 600 }}>Active</span>
            <div style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: 'var(--status-success)' }}></div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-col w-full h-full" style={{ overflowY: 'auto' }}>
        {/* Top Header */}
        <header className="flex items-center justify-between panel" style={{ borderRadius: 0, borderTop: 0, borderLeft: 0, borderRight: 0, padding: '1rem 2rem' }}>
          <h1 style={{ fontSize: '1.5rem', fontWeight: 500, letterSpacing: '-0.03em' }}>
            {activeTab === 'dashboard' ? 'Pipeline Overview' : 
             activeTab === 'content' ? 'ContentEngine (Generative Hub)' : 
             activeTab === 'cases' ? 'Historical Case CRM' : 
             'ADK Orchestration Server'}
          </h1>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2" style={{ color: 'var(--text-secondary)' }}>
              <Search size={18} />
              <input type="text" placeholder="Search cases, assets..." style={{ background: 'transparent', border: 'none', color: 'var(--text-primary)', outline: 'none', width: '200px' }} />
            </div>
            <Bell size={18} color="var(--text-secondary)" />
            <div style={{ width: '32px', height: '32px', borderRadius: '50%', backgroundColor: 'var(--border-highlight)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '12px', fontWeight: 600 }}>DOJ</div>
          </div>
        </header>

        {/* Dashboard View */}
        {activeTab === 'dashboard' && (
          <main style={{ padding: '2rem', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            
            {/* Metrics Row */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '1.5rem' }}>
              <MetricCard title="Total Monitored Assets" value={totalMetrics.totalSeized} subtitle={`${totalMetrics.activeCases} Active Cases`} />
              <MetricCard title="Projected USVSST Impact" value={totalMetrics.projectedUSVSST} subtitle="Based on late-stage pipeline" highlight />
              <MetricCard title="Data Freshness" value={totalMetrics.lastUpdate} subtitle="15 Tier-1 Sources Parsed" />
            </div>

            {/* Pipeline Chart */}
            <div className="panel flex-col gap-4">
              <h3 style={{ fontSize: '1.1rem', fontWeight: 500, marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Activity size={18} color="var(--accent-blue)" /> Asset Forfeiture Pipeline
              </h3>
              <div style={{ width: '100%', height: '300px' }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={pipelineStages} margin={{ top: 20, right: 30, left: 40, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" vertical={false} />
                    <XAxis dataKey="stage" stroke="var(--text-secondary)" tick={{ fill: 'var(--text-secondary)', fontSize: 12 }} />
                    <YAxis 
                      stroke="var(--text-secondary)" 
                      tick={{ fill: 'var(--text-secondary)', fontSize: 12 }} 
                      tickFormatter={(value) => `$${(value / 1000000).toFixed(0)}M`}
                    />
                    <Tooltip 
                      cursor={{ fill: 'var(--bg-surface-hover)' }}
                      contentStyle={{ backgroundColor: 'var(--bg-surface)', border: '1px solid var(--border-highlight)', borderRadius: '8px' }}
                      formatter={(value) => [`$${(value / 1000000).toFixed(1)}M`, 'Asset Value']}
                    />
                    <Bar dataKey="value" fill="var(--accent-blue)" radius={[4, 4, 0, 0]}>
                      {pipelineStages.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={index > 4 ? 'var(--status-success)' : 'var(--accent-blue)'} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Database Table */}
            <div className="panel flex-col gap-4">
              <div className="flex items-center justify-between" style={{ marginBottom: '1rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                  <h3 style={{ fontSize: '1.1rem', fontWeight: 500, margin: 0, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <Gavel size={18} color="var(--accent-blue)" /> Active Verified Cases
                  </h3>
                  <button 
                    onClick={handleGovWatchTrigger}
                    disabled={isScraping}
                    style={{ background: isScraping ? 'var(--bg-surface-hover)' : 'var(--accent-blue)', color: 'white', border: 'none', padding: '0.4rem 0.8rem', borderRadius: '4px', cursor: isScraping ? 'wait' : 'pointer', fontSize: '0.8rem', fontWeight: 500, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <Database size={14} /> {isScraping ? 'GovWatch Scanning In Real Time...' : 'Force Live Web Scrape (ADK)'}
                  </button>
                </div>
              </div>
              <div style={{ overflowX: 'auto' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.9rem' }}>
                  <thead>
                    <tr style={{ borderBottom: '1px solid var(--border-color)', color: 'var(--text-tertiary)' }}>
                      <th style={{ padding: '1rem 0', fontWeight: 500 }}>Docket / Name</th>
                      <th style={{ padding: '1rem 0', fontWeight: 500 }}>Category</th>
                      <th style={{ padding: '1rem 0', fontWeight: 500 }}>Stage</th>
                      <th style={{ padding: '1rem 0', fontWeight: 500 }}>Seized Value</th>
                      <th style={{ padding: '1rem 0', fontWeight: 500 }}>Data Source (Verified)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {liveCases.map((c, idx) => (
                      <tr key={idx} style={{ borderBottom: '1px solid var(--border-color)', transition: 'background-color 0.2s ease', backgroundColor: c.source.includes('Live Pipeline') ? 'rgba(78, 171, 245, 0.05)' : 'transparent' }}>
                        <td style={{ padding: '1rem 0' }}>
                          <div style={{ fontWeight: 500 }}>{c.id}</div>
                          <div style={{ color: 'var(--text-secondary)', fontSize: '0.8rem' }}>{c.name}</div>
                        </td>
                        <td style={{ padding: '1rem 0' }}>{c.category}</td>
                        <td style={{ padding: '1rem 0' }}>
                          <span style={{ display: 'inline-block', padding: '0.2rem 0.6rem', borderRadius: '12px', fontSize: '0.75rem', fontWeight: 600, backgroundColor: 'var(--bg-surface-hover)', border: '1px solid var(--border-color)' }}>
                            {c.stage}
                          </span>
                        </td>
                        <td className="data-value" style={{ padding: '1rem 0' }}>
                           {typeof c.seizedValue === 'number' ? `$${(c.seizedValue / 1000000).toFixed(1)}M` : c.seizedValue}
                        </td>
                        <td style={{ padding: '1rem 0' }}>
                          <div className="flex items-center gap-2">
                            <span style={{ color: c.source.includes('Live') ? 'var(--accent-blue)' : 'var(--status-success)', display: 'flex', alignItems: 'center' }}><ShieldCheck size={14} /></span>
                            <div>
                              <div style={{ fontWeight: 500, fontSize: '0.85rem' }}>{c.source}</div>
                              <div style={{ color: 'var(--text-tertiary)', fontSize: '0.75rem' }}>{c.lastVerified}</div>
                            </div>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

          </main>
        )}

        {/* Content Hub View */}
        {activeTab === 'content' && (
          <main style={{ padding: '2rem', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            <div className="flex items-center justify-between">
              <div>
                <h2 style={{ fontSize: '1.25rem', fontWeight: 500, margin: 0, color: 'var(--text-primary)' }}>Genkit Content Engine</h2>
                <p style={{ margin: '0.5rem 0 0 0', color: 'var(--text-secondary)' }}>Auto-generated compliance and beneficiary updates powered by Genkit & ADK Pipelines.</p>
              </div>
              <button 
                onClick={handleForceGeneration}
                disabled={isGenerating}
                style={{ background: isGenerating ? 'var(--text-tertiary)' : 'var(--accent-blue)', color: 'white', border: 'none', padding: '0.6rem 1.2rem', borderRadius: '4px', cursor: isGenerating ? 'wait' : 'pointer', fontWeight: 500, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Mail size={16} /> {isGenerating ? 'Running IntelScout Audit...' : 'Force Generation Run'}
              </button>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
              {generatedContent ? (
                <>
                  <ContentCard 
                    title="Motley Rice Status Request" 
                    type="Lawyer Accountability" 
                    status="Generated"
                    excerpt={generatedContent.generatedContent.lawyerEmail.substring(0, 160) + "..."}
                    onReview={() => setSelectedContentInfo({ title: "Lawyer Accountability - Motley Rice", content: generatedContent.generatedContent.lawyerEmail })}
                  />
                  <ContentCard 
                    title="USVSST Beneficiary Newsletter" 
                    type="Email Blast" 
                    status="Generated"
                    excerpt={generatedContent.generatedContent.newsletter.substring(0, 160) + "..."}
                    onReview={() => setSelectedContentInfo({ title: "USVSST Beneficiary Newsletter", content: generatedContent.generatedContent.newsletter })}
                  />
                  <ContentCard 
                    title="USVSST Verified Blog Post" 
                    type="Public Announcement" 
                    status="Generated"
                    excerpt={generatedContent.generatedContent.blogPost.substring(0, 160) + "..."}
                    onReview={() => setSelectedContentInfo({ title: "Public Blog Post Announcement", content: generatedContent.generatedContent.blogPost })}
                  />
                  <ContentCard 
                    title="X/LinkedIn Social Alert" 
                    type="Social Media" 
                    status="Generated"
                    excerpt={generatedContent.generatedContent.socialMediaPost.substring(0, 160) + "..."}
                    onReview={() => setSelectedContentInfo({ title: "Social Media Alert Thread", content: generatedContent.generatedContent.socialMediaPost })}
                  />
                  <div className="panel flex-col gap-2" style={{ gridColumn: 'span 2' }}>
                      <h4 style={{ color: 'var(--accent-blue)', margin: 0, fontSize: '0.9rem' }}>IntelScout Audit Facts (Zero-Hallucination)</h4>
                      <pre style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', overflowX: 'auto', background: 'var(--bg-base)', padding: '1rem', border: '1px solid var(--border-highlight)' }}>
{JSON.stringify(generatedContent.verifiedData, null, 2)}
                      </pre>
                  </div>
                </>
              ) : (
                <>
                  <ContentCard 
                    title="Motley Rice Status Request" 
                    type="Lawyer Accountability" 
                    status="Pending Review"
                    excerpt="Dear Legal Team: Based on today's `intelscout` verified data, Case 1:24-cv-00123 has entered the Litigation stage. Please confirm strategic alignment..."
                  />
                  <ContentCard 
                    title="USVSST Beneficiary Newsletter" 
                    type="Email Blast" 
                    status="Approved"
                    excerpt="Good morning. We are pleased to report that $112M has successfully transitioned to Liquidation status in the Iranian Oil Tanker case..."
                  />
                  <ContentCard 
                    title="Case Breakdown: Seizures up 12%" 
                    type="LinkedIn / Blog" 
                    status="Drafting"
                    excerpt="Federal asset forfeiture pipelines have seen a 12% increase in Crypto/Sanctions seizures this quarter..."
                  />
                  <ContentCard 
                    title="60-Second Video Update Script" 
                    type="Video Storyboard" 
                    status="Ready for Production"
                    excerpt="[SCENE 1: Graphic showing $3.4B] VO: The USVSST Fund continues to track massive federal forfeitures..."
                  />
                </>
              )}
            </div>
          </main>
        )}

        {/* Cases Database View */}
        {activeTab === 'cases' && (
          <main style={{ padding: '2rem', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            <div className="flex items-center justify-between">
              <div>
                <h2 style={{ fontSize: '1.25rem', fontWeight: 500, margin: 0, color: 'var(--text-primary)' }}>Historical Case CRM</h2>
                <p style={{ margin: '0.5rem 0 0 0', color: 'var(--text-secondary)' }}>Searchable repository of all monitored federal actions and historical intelligence.</p>
              </div>
            </div>
            <div className="panel" style={{ overflowX: 'auto', minHeight: '500px' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.9rem' }}>
                <thead>
                  <tr style={{ borderBottom: '1px solid var(--border-color)', color: 'var(--text-tertiary)' }}>
                    <th style={{ padding: '1rem 0', fontWeight: 500 }}>Docket / Name</th>
                    <th style={{ padding: '1rem 0', fontWeight: 500 }}>Category</th>
                    <th style={{ padding: '1rem 0', fontWeight: 500 }}>Current Stage</th>
                    <th style={{ padding: '1rem 0', fontWeight: 500 }}>Identified Value</th>
                    <th style={{ padding: '1rem 0', fontWeight: 500 }}>ADK Assignment</th>
                  </tr>
                </thead>
                <tbody>
                  {[...liveCases, ...casesData].map((c, idx) => (
                    <tr key={idx} style={{ borderBottom: '1px solid var(--border-color)', transition: 'background-color 0.2s ease' }}>
                      <td style={{ padding: '1rem 0' }}>
                        <div style={{ fontWeight: 500, color: 'var(--accent-blue)' }}>{c.id}</div>
                        <div style={{ color: 'var(--text-secondary)', fontSize: '0.8rem', maxWidth: '300px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{c.name}</div>
                      </td>
                      <td style={{ padding: '1rem 0' }}>{c.category}</td>
                      <td style={{ padding: '1rem 0' }}>
                        <span style={{ display: 'inline-block', padding: '0.2rem 0.6rem', borderRadius: '12px', fontSize: '0.75rem', fontWeight: 600, backgroundColor: 'var(--bg-surface-hover)', border: '1px solid var(--border-color)' }}>
                          {c.stage}
                        </span>
                      </td>
                      <td className="data-value" style={{ padding: '1rem 0' }}>
                          {typeof c.seizedValue === 'number' ? `$${(c.seizedValue / 1000000).toFixed(1)}M` : c.seizedValue}
                      </td>
                      <td style={{ padding: '1rem 0' }}>
                         <span style={{ color: 'var(--text-tertiary)', fontSize: '0.8rem', padding: '0.2rem 0.4rem', border: '1px solid var(--border-highlight)' }}>Agent IntelScout</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </main>
        )}

        {/* ADK Pipelines View */}
        {activeTab === 'adk' && (
          <main style={{ padding: '2rem', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            <div className="flex items-center justify-between">
              <div>
                <h2 style={{ fontSize: '1.25rem', fontWeight: 500, margin: 0, color: 'var(--text-primary)' }}>ADK Orchestration Server</h2>
                <p style={{ margin: '0.5rem 0 0 0', color: 'var(--text-secondary)' }}>Live system health, API latencies, and multi-agent Genkit performance.</p>
              </div>
              <div style={{ display: 'flex', gap: '0.5rem' }}>
                <span style={{ padding: '0.4rem 0.8rem', backgroundColor: 'var(--bg-surface)', border: '1px solid var(--border-highlight)', borderRadius: '4px', fontSize: '0.8rem', color: 'var(--status-success)', fontWeight: 500, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <Activity size={14}/> ALL SYSTEMS NOMINAL
                </span>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '1rem' }}>
              <MetricCard title="Genkit Avg Latency" value="1.2s" subtitle="Gemini 2.5 Pro / Flash" />
              <MetricCard title="IntelScout Ejection Rate" value="94.2%" subtitle="Hallucinations blocked" highlight />
              <MetricCard title="Memory Layer Size" value="8,401" subtitle="Vector Embeddings" />
              <MetricCard title="GovWatch Bots" value="12" subtitle="Active PACER/SEC feeds" />
            </div>

            <div className="panel flex-col gap-2" style={{ backgroundColor: '#0a0e17', border: '1px solid var(--border-highlight)' }}>
              <div className="flex items-center gap-2" style={{ borderBottom: '1px solid rgba(255,255,255,0.1)', paddingBottom: '0.5rem', marginBottom: '0.5rem' }}>
                <div style={{ display: 'flex', gap: '6px' }}>
                  <div style={{ width: '10px', height: '10px', borderRadius: '50%', backgroundColor: '#ff5f56' }}></div>
                  <div style={{ width: '10px', height: '10px', borderRadius: '50%', backgroundColor: '#ffbd2e' }}></div>
                  <div style={{ width: '10px', height: '10px', borderRadius: '50%', backgroundColor: '#27c93f' }}></div>
                </div>
                <span style={{ color: 'var(--text-tertiary)', fontSize: '0.8rem', fontFamily: 'monospace', marginLeft: '0.5rem' }}>genkit-server-tty1</span>
              </div>
              <pre style={{ margin: 0, fontSize: '0.85rem', color: 'var(--status-success)', fontFamily: '"JetBrains Mono", monospace', lineHeight: '1.5', whiteSpace: 'pre-wrap' }}>
{`[2026-03-20 12:44:01] 🚀 USVSST ADK Genkit Backend listening on port 3000
[2026-03-20 12:44:03] 📡 govwatch: Initiating live scrape of Tier-1 Federal feeds...
[2026-03-20 12:44:05] 🤖 intelscout: Auditing federal document: SEC Clarifies Application of Federal Securities Laws
[2026-03-20 12:44:08] ⚠️ intelscout Rejected: Document failed strict factual audit. Stage Hallucinated.
[2026-03-20 12:44:10] 🤖 intelscout: Auditing federal document: SEC Publishes Data on Public Offerings
[2026-03-20 12:44:14] ✅ intelscout Accepted: US vs $85,000,000 Crypto Seizure 
[2026-03-20 12:44:15] 🧠 [Memory Layer] Retrieving historical context for docket 1:24-cv-00123... 8 matches found.
[2026-03-20 12:44:18] 📝 ContentEngine generated 4 verified beneficiary updates.`}
              </pre>
            </div>
          </main>
        )}
      </div>
    </div>
  );
}

function NavItem({ icon, label, active, onClick }) {
  return (
    <div 
      onClick={onClick}
      style={{ 
        display: 'flex', alignItems: 'center', gap: '0.75rem', 
        padding: '0.75rem 1rem', 
        cursor: 'pointer',
        borderRadius: 'var(--radius-sm)',
        color: active ? 'var(--text-primary)' : 'var(--text-secondary)',
        backgroundColor: active ? 'var(--bg-surface)' : 'transparent',
        borderLeft: active ? '3px solid var(--accent-blue)' : '3px solid transparent',
        transition: 'all 0.2s ease',
        fontWeight: active ? 500 : 400
      }}
    >
      <span style={{ color: active ? 'var(--accent-blue)' : 'var(--text-tertiary)' }}>{icon}</span>
      <span style={{ fontSize: '0.9rem' }}>{label}</span>
    </div>
  );
}

function MetricCard({ title, value, subtitle, highlight }) {
  return (
    <div className="panel flex-col gap-2" style={{ borderTop: highlight ? '2px solid var(--accent-blue)' : undefined }}>
      <h4 style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', fontWeight: 500 }}>{title}</h4>
      <div className="data-value" style={{ fontSize: '2.5rem', color: highlight ? 'var(--status-success)' : 'var(--text-primary)' }}>{value}</div>
      <p style={{ margin: 0, fontSize: '0.8rem', color: 'var(--text-tertiary)' }}>{subtitle}</p>
    </div>
  );
}

function ContentCard({ title, type, status, excerpt, onReview }) {
  return (
    <div className="panel flex-col gap-4" style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div className="flex items-center justify-between">
        <span style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--accent-blue)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{type}</span>
        <span style={{ fontSize: '0.75rem', padding: '0.2rem 0.6rem', borderRadius: '12px', color: status === 'Approved' || status === 'Generated' ? '#0a0e17' : 'var(--text-primary)', backgroundColor: status === 'Approved' || status === 'Generated' ? 'var(--status-success)' : 'var(--bg-surface-hover)', border: '1px solid var(--border-color)' }}>{status}</span>
      </div>
      <h3 style={{ fontSize: '1.1rem', fontWeight: 500, margin: 0, color: 'var(--text-primary)' }}>{title}</h3>
      <p style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.6 }}>{excerpt}</p>
      <div style={{ marginTop: 'auto', paddingTop: '1rem', borderTop: '1px solid var(--border-color)', display: 'flex', justifyContent: 'flex-end' }}>
        <button onClick={onReview} style={{ background: 'none', border: 'none', color: 'var(--accent-blue)', cursor: 'pointer', fontSize: '0.85rem', fontWeight: 500, display: 'flex', alignItems: 'center', gap: '0.25rem' }}>Review Content <ArrowRight size={14} /></button>
      </div>
    </div>
  );
}
